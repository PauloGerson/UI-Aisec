
package entidade;


public class Circulo extends Forma{

    private double raio;

    public Circulo(String nome, String cor, double raio) {
        super(nome, cor);
        this.raio = raio;
    }

    public double area(){
        return Math.PI * raio * raio;
    }
    
 
}
