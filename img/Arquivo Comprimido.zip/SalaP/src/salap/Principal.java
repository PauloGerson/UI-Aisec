
package salap;


import entidade.Circulo;
import entidade.Retangulo;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        List <Retangulo> rt = new ArrayList<>();
        List <Circulo> cr = new ArrayList<>();
        
        int x;
        char tipo;
        String cor;
        double largura, altura, raio;
        
        System.out.print("Digite quantos objetos deseja cadastrar: ");
        x = ler.nextInt();
        
        for(int i=0; i< x; i++){
            System.out.print("Retangulo ou círculo (r/c): ");
            tipo = ler.next().charAt(0);
            System.out.print("Cor (preto/azul/vermelho): ");
            cor = ler.next();
            
            switch(tipo){
                case 'r':
                    System.out.print("Largura: ");
                    largura = ler.nextDouble();
                    System.out.print("Altura: ");
                    altura = ler.nextDouble();
                    rt.add(new Retangulo("Retangulo",cor,altura,largura));
                    break;
                case 'c':
                    System.out.print("Raio: ");
                    raio = ler.nextDouble();
                    cr.add(new Circulo("Circulo",cor,raio));
                    break;      
            }
        }
        System.out.println("Listando os objetos com suas respectivas áreas:");
        for(Retangulo r: rt){
            System.out.printf(r + " => Área: %.2f\n", r.area());
        }
        for(Circulo c: cr){
            System.out.printf(c + " => Área: %.2f\n", c.area());
        }
    }
    
}
