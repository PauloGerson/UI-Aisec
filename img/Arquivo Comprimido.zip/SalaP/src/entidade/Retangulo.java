
package entidade;

public class Retangulo {
    private String nome;
    private String cor;
    private double largura;
    private double altura;

    public Retangulo(String nome, String cor, double largura, double altura) {
        this.nome = nome;
        this.cor = cor;
        this.largura = largura;
        this.altura = altura;
    }
    
    public double area(){
        return altura * largura;
    }

    @Override
    public String toString() {
        return "nome = " + nome + " => cor = " + cor;
    }
    
    
}
