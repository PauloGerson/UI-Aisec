
package entidade;


public class Circulo {
    private String nome;
    private String cor;
    private double raio;

    public Circulo(String nome, String cor, double raio) {
        this.nome = nome;
        this.cor = cor;
        this.raio = raio;
    }
    
    public double area(){
        return Math.PI * raio * raio;
    }
    
    @Override
    public String toString() {
        return "nome = " + nome + " => cor = " + cor;
    }
}
