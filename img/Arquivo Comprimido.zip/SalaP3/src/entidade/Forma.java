
package entidade;

public abstract class Forma {
    private String nome;
    private String cor;   

    public Forma(String nome, String cor) {
        this.nome = nome;
        this.cor = cor;
    }
    
    @Override
    public String toString() {
        return "nome = " + nome + " => cor = " + cor;
    }
    
    public abstract double area();
}
